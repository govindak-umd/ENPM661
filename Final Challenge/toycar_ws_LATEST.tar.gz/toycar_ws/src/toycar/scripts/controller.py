#! /usr/bin/env python
# coding: utf-8
import rospy
from std_msgs.msg import Float64
import math
from controller_manager_msgs.srv import SwitchController


rospy.wait_for_service('/toycar/controller_manager/switch_controller')
def talker():

    pub1 = rospy.Publisher('/toycar/joint1_velocity_controller/command', Float64, queue_size=10)
    pub2 = rospy.Publisher('/toycar/joint2_velocity_controller/command', Float64, queue_size=10)
    # pub3 = rospy.Publisher('/toycar/joint3_position_controller/command', Float64, queue_size=10)
    pub4 = rospy.Publisher('/toycar/joint4_position_controller/command', Float64, queue_size=10)
    pub5 = rospy.Publisher('/toycar/joint5_position_controller/command', Float64, queue_size=10)


    rospy.init_node('toycar_talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz

    # switch_controller = rospy.ServiceProxy('/toycar/controller_manager/switch_controller', SwitchController)
    # ret0 = switch_controller(['joint_state_controller'], [], 2)
    # ret9 = switch_controller(['joint4_position_controller','joint5_position_controller'], [], 2)
    # ret3 = switch_controller(['joint1_position_controller','joint2_position_controller','joint3_position_controller'], [], 2)
    while not rospy.is_shutdown():
        vel = 1.0
        print('vel is', vel)
        # ret1 = switch_controller(['joint4_position_controller','joint5_position_controller'], [], 2) 
        pub1.publish(vel)
        pub2.publish(vel)
        # pub3.publish(vel)

        # ret4 = switch_controller([], ['joint1_position_controller','joint2_position_controller','joint3_position_controller'], 2)
        # ret5 = switch_controller(['joint4_position_controller','joint5_position_controller'], [], 2)
        
        pub4.publish(-0.28)
        pub5.publish(-0.28)
        
        # ret6 = switch_controller([],['joint4_position_controller','joint5_position_controller'], 2)
        
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        print('exception raised')
        pass