#! /usr/bin/env python
# coding: utf-8
import rospy
from std_msgs.msg import Float64
import math
from controller_manager_msgs.srv import SwitchController


rospy.wait_for_service('/toycar/controller_manager/switch_controller')
def talker():
    pub1 = rospy.Publisher('/toycar/joint1_position_controller/command', Float64, queue_size=10)
    # pub2 = rospy.Publisher('/toycar/joint2_position_controller/command', Float64, queue_size=10)
    # pub3 = rospy.Publisher('/toycar/joint3_position_controller/command', Float64, queue_size=10)
    pub4 = rospy.Publisher('/toycar/joint4_position_controller/command', Float64, queue_size=10)
    # pub5 = rospy.Publisher('/toycar/joint5_position_controller/command', Float64, queue_size=10)
    # pub6 = rospy.Publisher('/toycar/joint6_position_controller/command', Float64, queue_size=10)
    rospy.init_node('toycar_talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        vel = 2.0
        print('vel is', vel)
        position_value = 0.0
        print('position_value is', position_value)
        # rospy.loginfo(vel)
        # pub2.publish(vel)
        # rospy.loginfo(vel)
        switch_controller = rospy.ServiceProxy('/toycar/controller_manager/switch_controller', SwitchController)
        ret1 = switch_controller(['joint4_position_controller'], [], 2)
        ret3 = switch_controller(['joint1_position_controller'], ['joint4_position_controller'], 2)
        pub1.publish(vel)
        # pub3.publish(vel)
        ret4 = switch_controller([], ['joint1_position_controller'], 2)
        pub4.publish(position_value)
        # pub5.publish(position_value)
        # pub6.publish(position_value)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        print('exception raised')
        pass

